﻿=== Civ V Animated 2 Cursor Set ===

By: uaeaae (http://www.rw-designer.com/user/86860) thefirstuaeaae@gmail.com

Download: http://www.rw-designer.com/cursor-set/civ-v-animated-2

Author's description:

like the last set, but with only the files listed in the pointers below:
normal select: pointer
help: airbomb
background: go to
busy: waiting 
precision select: target
text select: edit
handwriting: missile
unavailable: attack
vertical: size v
horizontal: size h
diagonal 1: size diagonal 1
diagonal 2: size diagonal 2
move: move
alternate select: ping
link select: link
location select: found
person select: move citizen

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.